package com.example.grow_it

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
